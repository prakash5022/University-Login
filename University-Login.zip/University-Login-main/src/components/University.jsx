import React from 'react'
import Data from './Data'

const data = Data
console.log(data);

export const University = () => {
  return (
    <div>University</div>
  )
}
